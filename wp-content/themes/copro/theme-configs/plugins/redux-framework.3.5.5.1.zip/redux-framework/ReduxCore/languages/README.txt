Please visit: https://github.com/ReduxFramework/ReduxFramework/wiki/Translate for details on how you can help.
